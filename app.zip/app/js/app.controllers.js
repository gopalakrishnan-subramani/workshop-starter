angular.module("app.controllers", []) 

.run(function(){
    console.log("app controller run");
})

.config(function() {
    console.log("app cont config");
})

.controller("HeaderController", function($scope) {
    console.log("HeaderController");
    $scope.title = "Header";

    $scope.offer = Math.ceil(Math.random() * 100);

    $scope.generate = function() {
        console.log("generate called");
         //$scope.offer = Math.ceil(Math.random() * 100);
    }


    setInterval(function() {
        $scope.offer = Math.ceil(Math.random() * 100);
        //console.log($scope.offer);
        $scope.$digest();
    }, 3000);
    

})

