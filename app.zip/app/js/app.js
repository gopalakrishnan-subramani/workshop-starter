angular.module("productApp", [
    "ui.router",
    "app.config",
    "app.controllers",
    "product.module"
])

.run(function($rootScope, apiEndPoint){
    console.log("run method ", apiEndPoint);
    $rootScope.title = 'Product App';

    $rootScope.setTitle = function(title) {
        $rootScope.title = title;
    }
})

.run(function($injector){
    console.log("run 2", $injector.get("apiEndPoint"));
    var rs = $injector.get("$rootScope");
    rs.title = "Angular App";

})

.config(function(CART_SIZE) {
    console.log("config 1 ", CART_SIZE);
})

