angular.module("app.config", [])

.value("apiEndPoint", "http://localhost:7070")

.value("config", {
    apiEndPoint: "http://localhost:7070"
})
.constant("CART_SIZE", 100)


.config(function($stateProvider){
    $stateProvider
    .state("home", {
        url: "",
        template: "<h2>Home Page</h2>"
    })
})

