angular.module("app.config", [])

.value("apiEndPoint", "http://localhost:7070")

.constant("CART_SIZE", 100)