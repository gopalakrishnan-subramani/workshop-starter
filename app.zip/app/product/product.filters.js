angular.module("product.filters", [])
//products | byYear
//product | byYear:2010
.filter("byYear", function(apiEndPoint, $http){
    console.log("at filter ", apiEndPoint);

    return function(products, year) {
        if (!products)
            return;
        
        if (!year) {
            return products;
        }

        var results = [];
        angular.forEach(products, function(product){
            if (product.year == year) {
                results.push(product);
            }
        })

        return results;
    }
})