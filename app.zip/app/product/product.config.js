angular.module("product.config", [])

.config(function($stateProvider){
    $stateProvider
    .state("products", {
        url: "/products", //localhost:3000/#/products
        templateUrl : "/app/product/templates/product-list.html",
        controller : "ProductListController"
    })
})