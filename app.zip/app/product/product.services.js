angular.module("product.services", [])

.service("productService", function($http, apiEndPoint) {

    console.log("productService created");

    /*
    this.getProducts = function() {
        return [
            {name: 'iPhone', year: 2010},
            {name: 'Nexus', year: 2010}
        ]  
    }*/

    this.getProducts = function() {
        return $http
               .get(apiEndPoint + "/api/products")
               .then(function(response){
                   return response.data;
               })

    }
})