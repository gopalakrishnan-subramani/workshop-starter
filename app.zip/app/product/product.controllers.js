angular.module("product.controllers", [])

.controller("ProductListController", function($scope, 
                                    productService){

  console.log("ProductListController created");

  //$scope.year = "2010";



  //$scope.products = productService.getProducts();

  productService.getProducts()
  .then(function(products){
      //console.log(response);
      $scope.products = products;
  })


  //FIXME: 
  $scope.yearChanged = function() {
      console.log($scope.year);
      console.log("year changed");
  }

})