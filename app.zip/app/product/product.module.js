angular.module("product.module", [
    "product.config",
    "product.controllers",
    "product.services",
    "product.filters",
    "product.directives"
])